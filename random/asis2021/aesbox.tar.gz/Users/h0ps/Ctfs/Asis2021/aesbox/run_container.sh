!#/bin/bash

docker run -d -p 10111 --rm -it aes
