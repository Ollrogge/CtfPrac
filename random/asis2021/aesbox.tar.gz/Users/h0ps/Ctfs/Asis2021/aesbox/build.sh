#!/bin/bash

docker build -t aes .
