#!/bin/bash

./ynetd -p 10111 ./aes

