#!/bin/bash
python3 -u /home/image_factory/nc_pow_guard.py && /home/image_factory/chall