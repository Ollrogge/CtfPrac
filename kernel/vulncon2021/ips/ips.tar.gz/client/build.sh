musl-gcc -static -o exp exp.c
mv exp cpio_files/
