./build.sh
./create_cpio.sh
./start.sh
