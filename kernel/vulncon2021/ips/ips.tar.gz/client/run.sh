qemu-system-x86_64 \
  -S \
  -m 256M \
  -initrd roofts.cpio \
  -kernel ./bzImage -nographic \
  -monitor /dev/null \
  -no-reboot \
  -append "kpti=1 +smep +smap kaslr root=/dev/ram rw console=ttyS0 oops=panic paneic=1 quiet"
