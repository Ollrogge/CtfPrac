# Fullchain

Chromium is built from commit `1be58e78c7ec6603d416aed4dfae757334cd4e1e`. Linux is v5.12.9, you can download the sources from [here](https://cdn.kernel.org/pub/linux/kernel/v5.x/linux-5.12.9.tar.xz). The VM is built from Debian.

## Setup

This challenge runs in a QEMU vm. Use `run_qemu.py` to run it.
