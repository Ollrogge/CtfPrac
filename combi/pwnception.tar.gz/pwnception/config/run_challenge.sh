#! /bin/bash
cd /home/ctf && timeout 300 ./main ./kernel ./userland
